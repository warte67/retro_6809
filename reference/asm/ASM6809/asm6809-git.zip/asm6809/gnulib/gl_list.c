#include <config.h>
#define GL_LIST_INLINE _GL_EXTERN_INLINE
#include "gl_list.h"
